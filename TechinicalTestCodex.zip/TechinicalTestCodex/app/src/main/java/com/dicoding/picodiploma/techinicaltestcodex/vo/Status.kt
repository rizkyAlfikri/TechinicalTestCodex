package com.dicoding.picodiploma.techinicaltestcodex.vo

enum class Status {
    LOADING,
    SUCCESS,
    ERROR
}