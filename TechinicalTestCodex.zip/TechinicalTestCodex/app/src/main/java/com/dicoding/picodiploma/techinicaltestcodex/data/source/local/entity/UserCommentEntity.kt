package com.dicoding.picodiploma.techinicaltestcodex.data.source.local.entity

data class UserCommentEntity(
    var text: String
)