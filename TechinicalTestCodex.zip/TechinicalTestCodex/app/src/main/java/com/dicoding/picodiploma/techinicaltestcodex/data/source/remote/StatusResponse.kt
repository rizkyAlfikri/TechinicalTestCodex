package com.dicoding.picodiploma.techinicaltestcodex.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}